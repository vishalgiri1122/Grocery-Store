<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Product;

class OrderController extends Controller
{
    public function orders(Request $request)
    {
        // Retrieve orders with associated carts and products
        $orders = Order::with('user','cart.product')->get();
        $title = "Orders";
        // dd($orders);
        return view('admin.orders.index', compact('orders','title'));
    }
    public function order_details($id){
        $order = Order::with('user','cart.product')->where("id",$id)->first();
        $title = "Order Details";
        // dd($order);
        return view("admin.orders.details",get_defined_vars());
    }
    public function order_update_status(Request $request){
        $id = $request->itemId;
        $status = $request->status;
        // dd($status);
        $order = Order::find($id);
        $order->status = $status;
        // dd($order);
        // $email = $order->email;
        // if($order->status == 'Complete'){
        //     $data = [
        //     'orderId' => $id, // You can add more data as needed
        //     ];
        //     Mail::send('admin.email.order_complete_template', $data, function ($message) use ($email) {
        //     $message->to('keharsarfraz90@gmail.com')
        //     ->cc($email)
        //     ->subject('Order Completed');
        //     $message->from('keharjohn@gmail.com', 'eshop online store');
        //     // dd($carts);
        // });
        // }
        $order->save();
        return view("admin.orders.index",get_defined_vars());
    }
    public function track_order($id){
        $orders = Order::where('user_id',$id)->with('user','cart.product.category')->get();
        // dd($orders);
        return view('website.track_order',get_defined_vars());
    }
}
