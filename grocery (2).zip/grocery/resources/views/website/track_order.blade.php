@include('website.layout.head')
<style>
    @media(min-width: 992px){
        #container{
            height: 75vh;
        }
    }
</style>
<div class="container-fluid pt-5" id="container">
    <div class="">
        @if($orders->contains('status', 'Pending'))
            <p class="text-success"> Your pending orders will arrive within 45 minutes of order time. </p>
        @endif
        <table class="table table-striped">
          <thead>
            <tr>
              <!--<th scope="col">#</th>-->
              <th scope="col">Category</th>
              <th scope="col">Product</th>
              <th scope="col">Quantity</th>
              <th scope="col">Price</th>
              <th scope="col">Created at</th>
              <th scope="col">Status</th>
            </tr>
          </thead>
          <tbody>
              @foreach($orders as $order)
            <tr>
              <!--<th scope="row">1</th>-->
              <td>{{ $order->cart->product->category->category_name }}</td>
              <td>{{ $order->cart->product->name }}</td>
              <td>{{ $order->cart->qty }}</td>
              <td>{{ $order->cart->product->price * $order->cart->qty }}</td>
              <td>{{ $order->created_at }}</td>
              <td>{{ $order->status }}</td>
            </tr>
            @endforeach()
          </tbody>
        </table>
    </div>

</div>


@include('website.layout.footer')



