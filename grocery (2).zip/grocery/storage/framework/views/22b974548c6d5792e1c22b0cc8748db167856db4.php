<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layout.header_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <script>
        <?php if(Session::has('category_added')): ?>
       toastr.options = {
       "closeButton": true,
       "progressBar": true
    }
       toastr.success("<?php echo e((session('category_added'))); ?>")
    <?php endif; ?>
      </script>
    <div class="page-wrapper">

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mt-4 mb-4">
                                    <h2 class="strong"> Coupons </h2>
                                    <a href="<?php echo e(url('add_coupon')); ?>">
                                        <button class="btn btn-success">Add Coupon</button>
                                    </a>
                                </div>
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Title</th>
                                                <th>Code</th>
                                                <th>Value</th>
                                                <th>Action</th>
                                                <th>Status</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <tr>
                                                <td><?php echo e($coupon->id); ?></td>
                                                <td><?php echo e($coupon->title); ?></td>
                                                <td><?php echo e($coupon->code); ?></td>
                                                <td><?php echo e($coupon->value); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('edit_coupon',['id'=>$coupon->id])); ?>">
                                                        <button class="btn btn-success">Edit Coupon</button>
                                                    </a>
                                                    <a href="<?php echo e(route('delete_coupon',['id'=>$coupon->id])); ?>">
                                                        <button class="btn btn-danger">Delete Coupon</button>
                                                    </a>
                                                </td>
                                                <td><?php echo e($coupon->status); ?></td>
                                            </tr>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ecommerce2\resources\views/admin/coupon/coupons.blade.php ENDPATH**/ ?>