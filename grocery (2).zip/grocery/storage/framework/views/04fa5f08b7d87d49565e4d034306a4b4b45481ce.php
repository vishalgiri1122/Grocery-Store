<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layout.header_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <script>
        <?php if(Session::has('product_added')): ?>
       toastr.options = {
       "closeButton": true,
       "progressBar": true
    }
       toastr.success("<?php echo e((session('product_added'))); ?>")
    <?php endif; ?>
      </script>
    <div class="page-wrapper">

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mt-4 mb-4">
                                    <h2 class="strong"> Order Details </h2>
                                </div>
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Country</th>
                                                <th>Username</th>
                                                <th>Address</th>
                                                <th>Apartment</th>
                                                <th>State</th>
                                                <th>Postal Code</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Product Name</th>
                                                <th>Product image</th>
                                                <th>Product price</th>
                                                <th>Quantity purchased</th>
                                                <th>Total Price</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td> <?php echo e($order->country); ?> </td>
                                                <td> <?php echo e($order->username); ?> </td>
                                                <td> <?php echo e($order->address); ?> </td>
                                                <td> <?php echo e($order->apartment); ?> </td>
                                                <td> <?php echo e($order->state); ?> </td>
                                                <td> <?php echo e($order->postal_code); ?> </td>
                                                <td> <?php echo e($order->email); ?> </td>
                                                <td> <?php echo e($order->phone); ?> </td>
                                                <td> <?php echo e($order->cart->product->name); ?> </td>
                                                <td> <img src="<?php echo e(asset("assets/admin/product_images/" . $order->cart->product->image)); ?>" alt="thumbnail" width=200> </td>
                                                <td> <?php echo e($order->cart->product->price); ?> </td>
                                                <td> <?php echo e($order->cart->qty); ?> </td>
                                                <td> <?php echo e($order->cart->qty * $order->cart->product->price); ?> </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\eommerce2\resources\views/admin/orders/details.blade.php ENDPATH**/ ?>