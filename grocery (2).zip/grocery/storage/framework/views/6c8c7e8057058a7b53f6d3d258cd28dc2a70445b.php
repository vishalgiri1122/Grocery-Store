<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="page-content--bge5">
        <div class="container">
            <div class="login-wrap">
                <div class="login-content">
                    <div class="login-logo">
                        
                        <a href="#">
                            <img src="<?php echo e(asset('assets/admin/images/icon/logo.png')); ?>" alt="CoolAdmin">
                        </a>
                    </div>
                    <div class="login-form">
                        <?php if(Session::has('message')): ?>

                         <div class="alert alert-success" role="alert">

                            <?php echo e(Session::get('message')); ?>


                        </div>

                    <?php endif; ?>
                        <form action="<?php echo e(route('forget.password.post')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="email_address">Email Address</label>
                                <input type="text" id="email_address" class="form-control" name="email" required autofocus>
                                <?php if($errors->has('email')): ?>

                                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>

                                  <?php endif; ?>
                            </div>
                            <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">Send Password Reset Link
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u336971226/domains/solecube.tech/public_html/grocery/resources/views/auth/forgetPassword.blade.php ENDPATH**/ ?>