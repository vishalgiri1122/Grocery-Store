<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layout.header_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <script>
        <?php if(Session::has('category_added')): ?>
       toastr.options = {
       "closeButton": true,
       "progressBar": true
    }
       toastr.success("<?php echo e((session('category_added'))); ?>")
    <?php endif; ?>
      </script>
    <div class="page-wrapper">

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-9">
                                <div class="mt-4 mb-4">
                                    <h2 class="strong"> Categories </h2>
                                    <a href="<?php echo e(url('add_category')); ?>">
                                        <button class="btn btn-success">Add Category</button>
                                    </a>
                                </div>
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Category Name</th>
                                                <th>Category Thumbnail</th>
                                                <th>Action</th>
                                                <th>Status</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <tr>
                                                <td><?php echo e($cat->id); ?></td>
                                                <td><?php echo e($cat->category_name); ?></td>
                                                <td> <img src="<?php echo e(asset('assets/admin/category_images/' . $cat->image )); ?>" alt="image" style="max-width:100px"> </td>

                                                <td>
                                                    <a href="<?php echo e(route('edit_category',['id'=>$cat->id])); ?>">
                                                        <button class="btn btn-success">Edit Category</button>
                                                    </a>
                                                    <a href="<?php echo e(route('delete_category',['id'=>$cat->id])); ?>">
                                                        <button class="btn btn-danger">Delete Category</button>
                                                    </a>
                                                </td>
                                                <td><?php echo e($cat->status); ?></td>
                                            </tr>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ecommerce2\resources\views/admin/category/categories.blade.php ENDPATH**/ ?>