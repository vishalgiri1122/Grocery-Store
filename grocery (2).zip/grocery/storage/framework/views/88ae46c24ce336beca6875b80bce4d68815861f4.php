<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layout.header_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <script>
        <?php if(Session::has('product_added')): ?>
       toastr.options = {
       "closeButton": true,
       "progressBar": true
    }
       toastr.success("<?php echo e((session('product_added'))); ?>")
    <?php endif; ?>
      </script>
    <div class="page-wrapper">

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mt-4 mb-4">
                                    <h2 class="strong"> Products </h2>
                                    <a href="<?php echo e(url('add_product')); ?>">
                                        <button class="btn btn-success">Add product</button>
                                    </a>
                                </div>
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning" id="products">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Name</th>
                                                <th>Category</th>
                                                <th>Image</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($prod->id); ?></td>
                                                <td><?php echo e($prod->name); ?></td>
                                                <td><?php echo e($prod->category->category_name); ?></td>
                                                <td> <img src="<?php echo e(asset('assets/admin/product_images/' . $prod->image )); ?>" alt="image" style="max-width:100px"> </td>
                                                <td><?php echo e($prod->price); ?></td>
                                                <td><?php echo e($prod->status); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('edit_product',['id'=>$prod->id])); ?>">
                                                        <button class="btn btn-success">Edit product</button>
                                                    </a>
                                                    <a href="<?php echo e(route('delete_product',['id'=>$prod->id])); ?>">
                                                        <button class="btn btn-danger">Delete product</button>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready( function () {
    $('#products').DataTable();
} );
</script>
<?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/product/products.blade.php ENDPATH**/ ?>