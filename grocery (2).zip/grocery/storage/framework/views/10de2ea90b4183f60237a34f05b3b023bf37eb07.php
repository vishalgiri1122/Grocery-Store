<?php echo $__env->make('website.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <script>
     <?php if(Session::has('success')): ?>
	toastr.options = {
	"closeButton": true,
	"progressBar": true
}
	toastr.success("<?php echo e((session('success'))); ?>")
<?php endif; ?>
   </script>
    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Customer - login</h1>
            <div class="d-inline-flex">
                <p class="m-0"><button class="btn btn-primary py-2 px-4" type="submit"> Back to Home </button></p>
                <!--<p class="m-0 px-2">-</p>-->
                <!--<p class="m-0">Contact</p>-->
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Contact Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5">
            <div class="col-lg-6 mx-auto mb-5">
                <div class="contact-form">
                    <div id="success"></div>
                    <form action="<?php echo e(url('userLogin')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="control-group mb-4">
                            <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" />
                        </div>
                        <div class="control-group mb-4">
                            <input type="password" class="form-control mb-2" id="password" name="password" placeholder="Password"
                               />
                               <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?> </span>
                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <button class="btn btn-primary py-2 px-4" type="submit"> LOGIN </button>
                        </div>
                    </form>
                    <div class="register-link mt-4">
                        <p>
                            Don't you have account?
                            <a href="<?php echo e(url('user/register')); ?>">Sign Up Here</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->

<?php echo $__env->make('website.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/u336971226/domains/solecube.tech/public_html/grocery/resources/views/website/user_login.blade.php ENDPATH**/ ?>