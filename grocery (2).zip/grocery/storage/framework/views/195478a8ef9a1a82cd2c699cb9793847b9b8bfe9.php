<?php echo $__env->make('website.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pt-5">
    <div class="">
        <?php if($orders->contains('status', 'Pending')): ?>
            <p class="text-success"> Your pending orders will arrive within 45 minutes of order time. </p>
        <?php endif; ?>
        <table class="table table-striped">
          <thead>
            <tr>
              <!--<th scope="col">#</th>-->
              <th scope="col">Category</th>
              <th scope="col">Product</th>
              <th scope="col">Quantity</th>
              <th scope="col">Price</th>
              <th scope="col">Created at</th>
              <th scope="col">Status</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <!--<th scope="row">1</th>-->
              <td><?php echo e($order->cart->product->category->category_name); ?></td>
              <td><?php echo e($order->cart->product->name); ?></td>
              <td><?php echo e($order->cart->qty); ?></td>
              <td><?php echo e($order->cart->product->price * $order->cart->qty); ?></td>
              <td><?php echo e($order->created_at); ?></td>
              <td><?php echo e($order->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
    </div>
    
</div>


<?php echo $__env->make('website.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php /**PATH /home/u336971226/domains/solecube.tech/public_html/grocery/resources/views/website/track_order.blade.php ENDPATH**/ ?>