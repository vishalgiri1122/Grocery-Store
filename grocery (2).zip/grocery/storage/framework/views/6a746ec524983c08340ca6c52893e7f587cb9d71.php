<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>GROCERY - STORE</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('assets/website/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('assets/website/css/style.css')); ?>" rel="stylesheet">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <style>
        .cat-item .cat-img img, .product-item .product-img img {
            transition: .5s;
            height: 340px;
        }
        .headAddtoCart{
            font-size: 24px;
            cursor: pointer;
        }
        .navbar-nav.ml-auto.py-0{
            align-items: center
        }
        @media(max-width:568px){
            .cat-item .cat-img img, .product-item .product-img img {
                height: 215px;
            }

        }
    </style>
</head>

<body>
<!-- Topbar Start -->
<div class="container-fluid">

    <div class="row align-items-center py-3 px-xl-5">
        <div class="col-lg-3 d-none d-lg-block">
            <a href="/" class="text-decoration-none">
                <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
            </a>
        </div>
        <div class="col-lg-9 col-12 text-left">
            <form action="">
                <div class="input-group w-100">
                    <input type="text" class="form-control" placeholder="Search for products">
                    <div class="input-group-append">
                        <span class="input-group-text bg-transparent text-primary">
                            <i class="fa fa-search"></i>
                        </span>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
<!-- Topbar End -->

<?php /**PATH C:\xampp\htdocs\ecommerce2\resources\views/website/layout/head.blade.php ENDPATH**/ ?>