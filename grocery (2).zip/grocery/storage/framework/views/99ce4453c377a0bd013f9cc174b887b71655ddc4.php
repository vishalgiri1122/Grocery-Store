<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layout.header_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <script>
        <?php if(Session::has('product_added')): ?>
       toastr.options = {
       "closeButton": true,
       "progressBar": true
    }
       toastr.success("<?php echo e((session('product_added'))); ?>")
    <?php endif; ?>
      </script>
    <div class="page-wrapper">

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mt-4 mb-4">
                                    <h2 class="strong"> Orders </h2>
                                </div>
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Username</th>
                                                <th>User Email</th>
                                                <th>Shipping Address</th>
                                                <th>Product Image</th>
                                                <th>Quantity</th>
                                                <th>Total Price</th>
                                                 <th>
                                                    Status
                                                </th>
                                                <th>
                                                    Details
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td> <?php echo e($order->id); ?> </td>
                                                <td> <?php echo e($order->username); ?> </td>
                                                <td> <?php echo e($order->email); ?> </td>
                                                <td> <?php echo e($order->country); ?> </td>
                                                <td> <img src="<?php echo e(asset('assets/admin/product_images/' . $order->cart->product->image)); ?>" alt="thumbnail" width=200> </td>
                                                <td> <?php echo e($order->cart->qty); ?> </td>
                                                <td> <?php echo e($order->cart->qty * $order->cart->product->price); ?> </td>
                                                <td> 
                                                <select class="status-select" data-item-id="<?php echo e($order->id); ?>"> 
                                                    <option value="Cancelled" <?php if($order->status == 'Cancelled'): ?> selected <?php endif; ?>> Cancel </option>
                                                    <option value="Complete" <?php if($order->status == 'Complete'): ?> selected <?php endif; ?>> Complete </option>
                                                </select>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url("order_details/" . $order->id)); ?>">
                                                        <button class="btn btn-success">See More Details</button>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    
    <script>
        $(document).ready(function () {
    // Listen for change events on select elements with class "status-select"
    $('.status-select').on('change', function () {
        // Get the selected value
        var selectedValue = $(this).val();
        // alert(selectedValue)
        // Get the data-item-id attribute to identify the item
        var itemId = $(this).data('item-id');

        // Send an AJAX request to the server
        $.ajax({
            url: 'order_update_status', // Replace with your server endpoint
            type: 'POST',
            data: {
                itemId: itemId,
                status: selectedValue,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function (response) {
                // Handle the server's response (if needed)
                console.log('Status updated successfully');
            },
            error: function (xhr, status, error) {
                // Handle errors (if any)
                console.error('Error:', error);
            }
        });
    });
});

    </script>
<?php /**PATH /home/u336971226/domains/solecube.tech/public_html/grocery/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>